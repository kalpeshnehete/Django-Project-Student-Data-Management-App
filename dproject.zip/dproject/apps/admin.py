from django.contrib import admin

from apps.models import Student

admin.site.register(Student)
